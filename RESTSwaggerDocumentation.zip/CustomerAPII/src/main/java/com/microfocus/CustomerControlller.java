package com.microfocus;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
public class CustomerControlller {

	private Customer c1=new Customer(1, "Peter");
	private Customer c2=new Customer(2, "Sarah");
	private List<Customer> allCustomers=Arrays.asList(c1,c2);
		
	
	
	@RequestMapping(value="/allcustomers", method=RequestMethod.GET)
	public List<Customer> m1()
	{
		return allCustomers;
	}
	
	@RequestMapping(value="/customer/{name}", method=RequestMethod.GET)
	public Customer m2(@PathVariable("name") String custName)
	{
		Customer c=null;
		
		for (Customer cust:allCustomers)
		{
			if (cust.getCustomerName().equals(custName))
			{
				c=cust;
				break;
			}
		}
		return c;
	}

}
